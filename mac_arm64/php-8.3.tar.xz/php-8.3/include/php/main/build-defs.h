/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=/Applications/EServer/childApp/php/php-8.3' '--with-config-file-path=/Applications/EServer/childApp/php/php-8.3/etc' '--enable-bcmath' '--enable-calendar' '--enable-exif' '--enable-ftp' '--enable-fpm' '--enable-gd=shared' '--with-external-gd' '--enable-mbstring' '--enable-mbregex' '--enable-opcache' '--enable-soap' '--enable-sockets' '--with-bz2=/Applications/EServer/Library/bzip2' '--with-curl=shared' '--with-gmp=/Applications/EServer/Library/gmp' '--with-iconv=/Applications/EServer/Library/libiconv' '--with-mysqli' '--with-openssl=shared' '--with-password-argon2=/Applications/EServer/Library/argon2' '--with-pdo-mysql' '--with-pgsql=/Applications/EServer/Library/libpq' '--with-pdo-pgsql=/Applications/EServer/Library/libpq' '--with-pdo-sqlite' '--with-sqlite3' '--with-libxml' '--with-zip' '--with-zlib' 'PKG_CONFIG_PATH=/Applications/EServer/Library/lib/pkgconfig'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/Applications/EServer/childApp/php/php-8.3/lib/php/extensions/no-debug-non-zts-20230831"
#define PHP_PREFIX              "/Applications/EServer/childApp/php/php-8.3"
#define PHP_BINDIR              "/Applications/EServer/childApp/php/php-8.3/bin"
#define PHP_SBINDIR             "/Applications/EServer/childApp/php/php-8.3/sbin"
#define PHP_MANDIR              "/Applications/EServer/childApp/php/php-8.3/php/man"
#define PHP_LIBDIR              "/Applications/EServer/childApp/php/php-8.3/lib/php"
#define PHP_DATADIR             "/Applications/EServer/childApp/php/php-8.3/share/php"
#define PHP_SYSCONFDIR          "/Applications/EServer/childApp/php/php-8.3/etc"
#define PHP_LOCALSTATEDIR       "/Applications/EServer/childApp/php/php-8.3/var"
#define PHP_CONFIG_FILE_PATH    "/Applications/EServer/childApp/php/php-8.3/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
