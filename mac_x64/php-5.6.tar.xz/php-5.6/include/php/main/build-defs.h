/*                                                                -*- C -*-
   +----------------------------------------------------------------------+
   | PHP Version 5                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2016 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig S�ther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

/* $Id$ */

#define CONFIGURE_COMMAND " './configure'  '--prefix=/Applications/EServer/childApp/php/php-5.6' '--with-config-file-path=/Applications/EServer/childApp/php/php-5.6/etc' '--enable-bcmath' '--enable-calendar' '--enable-exif' '--enable-ftp' '--enable-fpm' '--enable-mbstring' '--enable-mbregex' '--enable-soap' '--enable-sockets' '--enable-opcache' '--enable-zip' '--with-bz2=/Applications/EServer/Library/bzip2' '--with-curl=shared,/Applications/EServer/Library/curl' '--with-gd=shared' '--with-gmp=/Applications/EServer/Library/gmp' '--with-iconv=/Applications/EServer/Library/libiconv' '--with-mysqli' '--with-openssl=shared,/Applications/EServer/Library/openssl@1.1' '--with-pdo-mysql' '--with-libxml-dir=/Applications/EServer/Library/libxml2' '--with-jpeg-dir=/Applications/EServer/Library/jpeg' '--with-png-dir=/Applications/EServer/Library/libpng' '--with-freetype-dir=/Applications/EServer/Library/freetype' '--with-zlib-dir=/Applications/EServer/Library/zlib' 'CFLAGS=-Wno-implicit-function-declaration' 'PKG_CONFIG_PATH=/Applications/EServer/Library/freetype/lib/pkgconfig'"
#define PHP_ADA_INCLUDE		""
#define PHP_ADA_LFLAGS		""
#define PHP_ADA_LIBS		""
#define PHP_APACHE_INCLUDE	""
#define PHP_APACHE_TARGET	""
#define PHP_FHTTPD_INCLUDE      ""
#define PHP_FHTTPD_LIB          ""
#define PHP_FHTTPD_TARGET       ""
#define PHP_CFLAGS		"$(CFLAGS_CLEAN) -prefer-non-pic -static"
#define PHP_DBASE_LIB		""
#define PHP_BUILD_DEBUG		""
#define PHP_GDBM_INCLUDE	""
#define PHP_IBASE_INCLUDE	""
#define PHP_IBASE_LFLAGS	""
#define PHP_IBASE_LIBS		""
#define PHP_IFX_INCLUDE		""
#define PHP_IFX_LFLAGS		""
#define PHP_IFX_LIBS		""
#define PHP_INSTALL_IT		""
#define PHP_IODBC_INCLUDE	""
#define PHP_IODBC_LFLAGS	""
#define PHP_IODBC_LIBS		""
#define PHP_MSQL_INCLUDE	""
#define PHP_MSQL_LFLAGS		""
#define PHP_MSQL_LIBS		""
#define PHP_MYSQL_INCLUDE	""
#define PHP_MYSQL_LIBS		""
#define PHP_MYSQL_TYPE		""
#define PHP_ODBC_INCLUDE	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_SHARED_LIBADD 	""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_ORACLE_SHARED_LIBADD 	"@ORACLE_SHARED_LIBADD@"
#define PHP_ORACLE_DIR				"@ORACLE_DIR@"
#define PHP_ORACLE_VERSION			"@ORACLE_VERSION@"
#define PHP_PGSQL_INCLUDE	""
#define PHP_PGSQL_LFLAGS	""
#define PHP_PGSQL_LIBS		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PHP_SOLID_INCLUDE	""
#define PHP_SOLID_LIBS		""
#define PHP_EMPRESS_INCLUDE	""
#define PHP_EMPRESS_LIBS	""
#define PHP_SYBASE_INCLUDE	""
#define PHP_SYBASE_LFLAGS	""
#define PHP_SYBASE_LIBS		""
#define PHP_DBM_TYPE		""
#define PHP_DBM_LIB		""
#define PHP_LDAP_LFLAGS		""
#define PHP_LDAP_INCLUDE	""
#define PHP_LDAP_LIBS		""
#define PHP_BIRDSTEP_INCLUDE     ""
#define PHP_BIRDSTEP_LIBS        ""
#define PEAR_INSTALLDIR         "/Applications/EServer/childApp/php/php-5.6/lib/php"
#define PHP_INCLUDE_PATH	".:/Applications/EServer/childApp/php/php-5.6/lib/php"
#define PHP_EXTENSION_DIR       "/Applications/EServer/childApp/php/php-5.6/lib/php/extensions/no-debug-non-zts-20131226"
#define PHP_PREFIX              "/Applications/EServer/childApp/php/php-5.6"
#define PHP_BINDIR              "/Applications/EServer/childApp/php/php-5.6/bin"
#define PHP_SBINDIR             "/Applications/EServer/childApp/php/php-5.6/sbin"
#define PHP_MANDIR              "/Applications/EServer/childApp/php/php-5.6/php/man"
#define PHP_LIBDIR              "/Applications/EServer/childApp/php/php-5.6/lib/php"
#define PHP_DATADIR             "/Applications/EServer/childApp/php/php-5.6/share/php"
#define PHP_SYSCONFDIR          "/Applications/EServer/childApp/php/php-5.6/etc"
#define PHP_LOCALSTATEDIR       "/Applications/EServer/childApp/php/php-5.6/var"
#define PHP_CONFIG_FILE_PATH    "/Applications/EServer/childApp/php/php-5.6/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
